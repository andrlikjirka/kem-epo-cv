<?php

echo "<a href='/kem-epo-cv/ukol-4/seznam-zbozi.php'>Seznam zboží</a>&nbsp;&nbsp;&nbsp;";
echo "<a href='/kem-epo-cv/ukol-4/nove-zbozi.php'>Nové zboží</a><br>";
echo "<hr>";
?>